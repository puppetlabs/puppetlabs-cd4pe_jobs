$ErrorActionPreference = 'Stop'
#!/bin/bash
pdk test unit
